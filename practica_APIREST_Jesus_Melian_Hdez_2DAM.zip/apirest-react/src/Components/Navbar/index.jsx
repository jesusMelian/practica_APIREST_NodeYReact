import React from 'react'

export const Navbar = ({title}) => {
    return (
        <div>
            <h1 className="title">{title}</h1>
        </div>
    )
}
